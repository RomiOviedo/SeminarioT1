﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jardines2023.Entidades.Entidades
{
    public class Ventas
    {
        public int VentaId { get; set; }
        public DateTime FechaVenta { get; set; }
        public int ClienteId { get; set; }
        public char TransaccionId { get; set; }
        public Cliente Cliente { get; set; }
        public decimal Total { get; set; }
        public int EstadoOrden { get; set; }

    }
}
