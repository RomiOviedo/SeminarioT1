﻿using Jardines2023.Comun.Interfaces;
using Jardines2023.Comun.Repositorios;
using Jardines2023.Datos.Repositorios;
using Jardines2023.Entidades.Dtos.Venta;
using Jardines2023.Servicios.Interfaces;
using System;
using System.Collections.Generic;

namespace Jardines2023.Servicios.Servicios
{
    public class ServiciosVentas : IServiciosVentas
    {

        private readonly IRepositorioVentas _repositorioVentas;
        private readonly IRepositorioClientes _repositorioClientes;

        public ServiciosVentas()
        {
            _repositorioVentas = new RepositorioVentas();
            _repositorioClientes = new RepositorioClientes();
        }
        public List<VentaDto> GetVentas()
        {
            try
            {
                var listaVenta = _repositorioVentas.GetVentas();

                foreach (var item in listaVenta)
                {
                    var nombreCliente = _repositorioClientes.GetClientePorId(item.ClienteId);
                    item.NombreCliente = nombreCliente.Nombre;


                }
                return listaVenta;

            }
            catch (Exception)
            {

                throw;
            };
        }
    }
}
